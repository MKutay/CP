public class FirstPlayer {
    public void swapCards(int cards[], int S, int T) {
        stub.doSwap(0, 1);
    }

}
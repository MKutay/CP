public class SecondPlayer {

    public void guessCard(int S, int T, int target) {
        int val = stub.guess(0);
    }

}
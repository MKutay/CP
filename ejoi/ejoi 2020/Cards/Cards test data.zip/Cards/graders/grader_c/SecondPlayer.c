#include "stub.h"

void guessCard(int S, int T, int target){
	int val = guess(0);
}

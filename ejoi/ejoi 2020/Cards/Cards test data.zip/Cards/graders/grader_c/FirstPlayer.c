#include "stub.h"

void swapCards(int cards[], int S, int T){
	doSwap(0, 1);
}

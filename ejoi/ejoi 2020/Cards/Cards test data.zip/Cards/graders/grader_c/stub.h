void doSwap(int s1, int s2);
int guess(int idx);

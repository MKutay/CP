#include "stub.h"

int solve(int n){
	int res = query(1,2);
	return 2*n+1;
}


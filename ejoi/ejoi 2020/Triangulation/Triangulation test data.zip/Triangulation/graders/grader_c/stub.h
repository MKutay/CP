#ifndef TRIANGLES_GRADER
#define TRIANGLES_GRADER

int query(int a, int b);

#endif

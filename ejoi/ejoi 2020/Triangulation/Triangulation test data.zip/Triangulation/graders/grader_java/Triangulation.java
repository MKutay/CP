public class Triangulation {
    public int solve(int n) {
        int res = stub.query(1, 2);
        return 2 * n + 1;
    }
}
